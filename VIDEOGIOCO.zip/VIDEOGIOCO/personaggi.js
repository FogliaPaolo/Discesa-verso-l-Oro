const personaggi = [
    {
        id: "caula1",
        nome: "CAULA",
        descrizione: "Non fa un cazzo tutto il giorno",
        immagine: "./img/giocatore1DX.png", // Immagine di anteprima
        imgDX: "./img/giocatore1DX.png",    // Immagine per movimento a destra
        imgSX: "./img/giocatore1SX.png",    // Immagine per movimento a sinistra
        vita: "Non ha polmoni"
    },
    {
        id: "caula2",
        nome: "Gioele",
        descrizione: "Lo stesso di prima",
        immagine: "./img/caula2.jpeg", 
        imgDX: "./img/caula2.jpeg",    // Se non hai la versione SX, usa la stessa
        imgSX: "./img/caula2.jpeg",
        vita: "Ha la sclerosi multipla"
    }
];