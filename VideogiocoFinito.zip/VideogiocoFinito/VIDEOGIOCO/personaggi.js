const personaggi = [
    {
        id: "Giocatore1",
        nome: "Giocatore 1",
        descrizione: "Giocatore 1",
        immagine: "./img/giocatore1DX.png", // Immagine di anteprima
        imgDX: "./img/giocatore1DX.png",    // Immagine per movimento a destra
        imgSX: "./img/giocatore1SX.png",    // Immagine per movimento a sinistra
        vita: "3 cuori"
    },
    {
        id: "Giocatore2",
        nome: "Giocatore 2",
        descrizione: "Giocatore 2",
        immagine: "./img/personaggio2.png", // Immagine di anteprima
        imgDX: "./img/personaggio22.png",    // Se non hai la versione SX, usa la stessa
        imgSX: "./img/personaggio2.png",
        vita: "3 cuori"
    }
];